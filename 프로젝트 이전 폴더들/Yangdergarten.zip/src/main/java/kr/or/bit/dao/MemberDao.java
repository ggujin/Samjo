package kr.or.bit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import kr.or.bit.dto.Member;
import kr.or.bit.utils.ConnectionHelper;


/*
DB작업
CRUD 작업을 하기위한 함수를 생성하는 곳

koreamember table 에 데이터 에 대해서
전제조회 : select id, email ,content from koreamember
조건조회 : select id, email ,content from koreamember where id=?
수정 : update koreamember set email=? , content=? where id=?
삭제 : delete from koreamember where id=?
삽입 : insert into koreamember(id,email,content) values(?,?,?)

default 5개
필요하시면 함수는 추가 .....^^
*/
public class MemberDao {
	
	/* 
	[하영] 1. int joinOk(Member member) //회원가입
	[하영] 2. void loginOk(String id, String pwd) //로그인 > session.setAttribute("userid", rs.getString("id"));
	[하영] 3. void logOut() //로그아웃 = 세션종료 >> session.invalidate();
												response.sendRedirect("Ex02_JDBC_Login.jsp");
	
	[수진] 4. ArrayList<Member> getMemberList() throws SQLException //회원목록조회
	[수진] 7. Member updateMember(String name) //회원정보 수정
	[수진] 8. int deleteMember(String name) //회원정보 삭제
	
	[범수] 5. Member getMemberListByName(String name) //이름으로 회원검색 >> sql = select name from koreamember where REGEXP_LIKE(name,'^\w*?\w*$');
	[범수] 6. 5번함수 활용해서 [회원 상세보기] 기능구현 가능
	*/
	
	public int joinOk(Member m) {
		Connection conn =null;//추가
		PreparedStatement pstmt = null;
		int resultrow=0;
		
		try {
				conn= ConnectionHelper.getConnection("oracle");//추가
				
				String sql = "insert into koreamember(id,pwd,name,age,gender,email,ip) values(?,?,?,?,?,?,?)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, m.getId());
				pstmt.setString(2, m.getPwd());
				pstmt.setString(3, m.getName());
				pstmt.setInt(4, m.getAge());
				pstmt.setString(5, m.getGender());
				pstmt.setString(6, m.getEmail());
				pstmt.setString(7, m.getIp());
				
				resultrow = pstmt.executeUpdate();
				
		}catch(Exception e) {
			System.out.println("Insert : " + e.getMessage());
		}finally {
			ConnectionHelper.close(pstmt);
			ConnectionHelper.close(conn);
		}
		return resultrow;
	}
	
	
	public Member loginOk(String id, String pwd) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Member m = new Member();
		
		try{
			conn = ConnectionHelper.getConnection("oracle");
			String sql="select id, pwd from koreamember where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,id);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				m.setId(id);
				m.setPwd(pwd);
			}
			
		}catch(Exception e){
			System.out.println(e.getMessage());
		}finally{
			ConnectionHelper.close(rs);
			ConnectionHelper.close(pstmt);
		}
		
		return m;
	}

	
	public List<Member> getMemberListByName(String name) throws SQLException {
		System.out.println("DAO ok");
		PreparedStatement pstmt = null;
		        String sql= "select id, name, email from koreaMember WHERE name like ?";
		        
		        Connection conn = ConnectionHelper.getConnection("oracle");

		        System.out.println(conn);
		        pstmt = conn.prepareStatement(sql);

		        pstmt.setString(1, "%"+name+"%");

		        ResultSet rs = pstmt.executeQuery();

		        List<Member> memberList = new ArrayList<Member>();

		        while(rs.next()) {  //데이터 건수 만큼 반복
		            Member m = new Member();
		            m.setId(rs.getString("id"));
		            m.setEmail(rs.getString("email"));
		            m.setName(rs.getString("name"));
		            System.out.println(m.toString());
		            memberList.add(m);
		        }

		        ConnectionHelper.close(rs);
		        ConnectionHelper.close(pstmt);
		        ConnectionHelper.close(conn);

		        return memberList; //Arraylist 주소를 리턴
		    }

	public Member getMemberDetail(String id) throws SQLException {

		System.out.println("DAO ok");
		        PreparedStatement pstmt = null;
		        String sql= "select id,pwd,name,age,gender,email from koreaMember where id=?";

		        Connection conn = ConnectionHelper.getConnection("oracle");

		        System.out.println(conn);
		        pstmt = conn.prepareStatement(sql);

		        pstmt.setString(1, id);

		        ResultSet rs = pstmt.executeQuery();

		        List<Member> memberList = new ArrayList<Member>();
		        //데이터 4건
		        //[Memo][Memo][Memo][Memo]
		        //memolist.add()
		        Member m = new Member();
		        while(rs.next()) {  //데이터 건수 만큼 반복
		            m.setId(rs.getString("id"));
		            m.setEmail(rs.getString("email"));
		            m.setName(rs.getString("name"));
		            m.setAge(rs.getInt("age"));
		            m.setGender(rs.getString("gender"));
		            m.setPwd(rs.getString("pwd"));
		        }

		ConnectionHelper.close(rs);
		ConnectionHelper.close(pstmt);
		ConnectionHelper.close(conn);
		
		return m; //Arraylist 주소를 리턴
	}
	
	
	public List<Member> getMemberList() throws SQLException{
		Connection conn = ConnectionHelper.getConnection("oracle"); //객체 얻기x
        PreparedStatement pstmt = null;
        String sql="select id, pwd, name, age, gender, email  from koreaMember";
        pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        List<Member> memberList= new ArrayList<Member>();
        
        while(rs.next()) {
            Member m = new Member();
            m.setId(rs.getString("id"));
            m.setPwd(rs.getString("pwd"));
            m.setName(rs.getString("name"));
            m.setAge(rs.getInt("age"));
            m.setGender(rs.getString("gender"));
            m.setEmail(rs.getString("email"));
            
      memberList.add(m);
        }
        ConnectionHelper.close(rs);
        ConnectionHelper.close(pstmt);
        ConnectionHelper.close(conn); //반환하기
        
        return memberList;
    }
	
	
	 public int deleteMember(String id) {
	        Connection conn = null;
	        PreparedStatement pstmt = null;
	        int resultrow = 0;
	        try {
	            conn = ConnectionHelper.getConnection("oracle");
	            String sql = "delete from koreaMember where id=?";
	            pstmt = conn.prepareStatement(sql);
	            pstmt.setString(1, id);
	            resultrow = pstmt.executeUpdate();
	        } catch (Exception e) {
	            System.out.println(e.getMessage());
	        }finally {
	            ConnectionHelper.close(pstmt);
	            ConnectionHelper.close(conn);
	        }
	        return resultrow;
	}
	 
	 
	public Member MemberUpdate(String id) { // 수정할 정보 화면

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Member m = new Member();

		try {
			conn = ConnectionHelper.getConnection("oracle");// 추가

			String sql = "select id, pwd, name, age, gender, email from koreaMember where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				m.setId(rs.getString("id"));
				m.setPwd(rs.getString("pwd"));
				m.setName(rs.getString("name"));
				m.setAge(rs.getInt("age"));
				m.setGender(rs.getString("gender"));
				m.setEmail(rs.getString("email"));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			ConnectionHelper.close(pstmt);
			ConnectionHelper.close(conn);
		}
		return m;
	}

	 
	public int MemberUpdateSubmit(Member m) { // 수정한 정보 DB로 전송
		Connection conn = null;
		PreparedStatement pstmt = null;
		int resultrow = 0;

		try {
			conn = ConnectionHelper.getConnection("oracle");
			String sql = "update koreaMember set pwd=?, name=?, age=?, gender=?, email=?  where id=?";
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, m.getPwd());
			pstmt.setString(2, m.getName());
			pstmt.setInt(3, m.getAge());
			pstmt.setString(4, m.getGender());
			pstmt.setString(5, m.getEmail());
			pstmt.setString(6, m.getId());

			resultrow = pstmt.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			ConnectionHelper.close(pstmt);
			ConnectionHelper.close(conn);
		}
		return resultrow;
	}

	 
}




